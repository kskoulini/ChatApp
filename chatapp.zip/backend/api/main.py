import json
from flask import Blueprint,request,jsonify

from .extensions import mongo

main = Blueprint('main',__name__)

@main.route('/user/signup', methods=['POST'])
def signup():
    user_data = request.json
    if user_data:
        user_collection = mongo.db.users
        user_collection.insert(user_data)
        return {
        'code':200,
        'text':'Success'
        }
    return {
    'text':'Something went wrong'
    }

@main.route('/user/login', methods=['POST'])
def login():
    user_data = request.json
    if user_data:
        # user_data = json.dumps(user_data)
        # user_data = jsonify(user_data)
        user_collection = mongo.db.users
        username = user_data['username']
        identified_user = user_collection.find_one({'username':username})
        if(identified_user and user_data['password'] == identified_user['password']):
            res = {'code':200,'text':'success'}
            res['username'] = identified_user['username']
            res['phoneNumber'] = identified_user['phoneNumber']
        else:
            res = {'code':404,'text':'not found'}
        return (res)
    return {
    'text':'Something went wrong'
    }

@main.route('/home',methods=['POST'])
def index():
    user_collection = mongo.db.users
    user_collection.insert({'name':'Jessica'})
    return '<h1>Sing up here!</h1>'

import React,{useState,useEffect} from 'react';
import './App.css';

import Screen from './Screen/Screen';
import LoginScreen from './LoginScreen/LoginScreen';
import RegistrationScreen from './RegistrationScreen/RegistrationScreen';

const App = () => {

  //State Management
  const [REGISTERED_DATA,setREGISTERED_DATA] = useState({
    '1234567890':{
      id:123,
      name:'Bob',
      password:'abc'
    }
  });

  const [currentState,setCurrentState] = useState({
    page:'login',
    loggedIn:false,
    username:'',
    phoneNumber:'',
    img:''
  })
  
  const setLoggedIn = (val,username,phoneNumber) => {
    if(val){
      const cpy = {...currentState}
      cpy.loggedIn = true;
      cpy.username = username;
      cpy.phoneNumber = phoneNumber;
      setCurrentState(cpy)
    }
  }

  const setCurrentPage = (event,pageVal) => {
    event.preventDefault()
    const cpy = {...currentState};
    cpy.page = pageVal;
    setCurrentState(cpy);
  }

  // Return content
  return (
    currentState.loggedIn?<Screen/>:(
      currentState.page === 'login'?<LoginScreen setLoggedIn={setLoggedIn} setCurrentPage={setCurrentPage}/>:
      <RegistrationScreen setCurrentPage={setCurrentPage} REGISTERED_DATA={REGISTERED_DATA}/>
    )
  );
}

export default App;
//
// <div className="App">
//   <header className="App-header">
//     <img src={logo} className="App-logo" alt="logo" />
//     <p>
//       Edit <code>src/App.js</code> and save to reload.
//     </p>
//     <a
//       className="App-link"
//       href="https://reactjs.org"
//       target="_blank"
//       rel="noopener noreferrer"
//     >
//       Learn React
//     </a>
//   </header>
// </div>

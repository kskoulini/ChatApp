import React,{useState} from 'react';
import './LoginScreen.css';

const LoginScreen = props => {

  // State Management
  const [currentInput,setCurrentInput] = useState({
    username:'',
    password: ''
  });

  let REGISTERED_DATA = {
  '1234567890':{
    id:123,
    name:'Bob',
    password:'abc'
    }
  };

  // Login Validation
  const loginVerificationHandler = async event => {
    event.preventDefault()
    // console.log(currentInput);
    try
    {
      console.log('Loging In...');
      const responseData = await fetch('/user/login',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(currentInput)
        }
      );

      try{
        const userDataJSON = await responseData.json();
        console.log(userDataJSON);
        if(userDataJSON.code === 200){
          props.setLoggedIn(true,userDataJSON['username'],userDataJSON['phoneNumber'])
        }
      }catch(err){
        console.log(err);
        return;
      }
    }
    catch (err)
    {
      console.log(err);
      return;
    }

    // if((currentInput.userName in REGISTERED_DATA) && (REGISTERED_DATA[currentInput.userName].password === currentInput.password))
    // {
    //   console.log('correct');
    //   props.setLoggedIn(true)
    // }
    // else {
    //   console.log('incorrect');
    // }
    // console.log(currentInput);
  };

  const setCurrentUserName = event => {
    let ph_copy = {...currentInput};
    ph_copy.username = event.target.value;
    setCurrentInput(ph_copy);
  }

  const setCurrentPassword = event => {
    let current_copy = {...currentInput};
    current_copy.password = event.target.value;
    setCurrentInput(current_copy);
  }

  return(
    <div className="wrapper">
        <div className="container">
          <div className="login-container">
            <form className="login-form" action="" method="get" onSubmit={loginVerificationHandler} type="multipart/form-data">
              <div className="login-title">
                <p className="login-container-h1">Hello,</p>
                <p className="login-container-h2">Welcome to Chat&nbsp;:)</p>
              </div>
              <div style={{display:"none"}} className="login-errors">
                Invalid Credentials!
              </div>
              <label className="login-input-label" htmlFor="phone-input">Username</label>
              <input className="login-input" id="phone-input" placeholder="Enter Username" required onChange={setCurrentUserName} value={currentInput.userName}></input>
              <label className="login-input-label" htmlFor="password-input">Password</label>
              <input className="login-input" id="password-input" placeholder="Enter Password" type="password" required onChange={setCurrentPassword} value={currentInput.password}></input>
              <button id="login-button" type="submit" className="login-button">LOGIN</button>
              <p className="register-link-container">
                Need an account?&nbsp;
                <a href="" className="register-link" onClick={event => props.setCurrentPage(event,'register')}>Sign up</a>
              </p>
            </form>
          </div>
        </div>
    </div>
  )
}

export default LoginScreen;

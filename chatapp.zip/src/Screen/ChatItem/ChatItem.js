import React from 'react';
import './ChatItem.css';

const ChatItem = props => {

  let classList = ["person"];
  if(props.activechat){
    classList.push("active")
  }
  
  return(
          <React.Fragment>
            <li className={classList.join(" ")} data-chat={props.id.split('_').join('')} onClick={() => props.changeCurrentChatHandler(props.id)}>
                <img src={props.imgSrc} alt="" />
                <span className="name">{props.name}</span>
                <span className="time">{props.time}</span>
                <span className="preview">{props.preview}</span>
            </li>
          </React.Fragment>
        )
}

export default ChatItem;

import React from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import './ChatLog.css';

import MessageItem from './MessageItem/MessageItem';

const ChatLog = props => {
  
  let classList = ["chat"];
  if(props.activechat){
    classList.push("active-chat")
  }

  const generateMessagesList = data => {
    const Messagelist = [];
    data.forEach((msg, i) => {
      // console.log(msg);
      Messagelist.push(<MessageItem type={msg.type} text={msg.text} key={'msg_'+i}/>)
    });
    return Messagelist;
  }

  const generateMessageBlock  = data => {
    const MessageBlock = [];
    data.forEach((msgBlk, i) => {
      MessageBlock.push(
                          <div className="conversation-start" key={props.id}>
                            <span>{msgBlk.day}</span>
                          </div>
                        )
      MessageBlock.push(generateMessagesList(msgBlk.messageList));
    });
    return MessageBlock;
  }


  return(
          <React.Fragment>
            <div className={classList.join(" ")} data-chat={props.id}>
              <Scrollbars
                renderScrollbarHorizontal = {props => <div className="scrollbar-horizontal" />}
                autoHide
                autoHeight
                autoHeightMin={100}
                autoHeightMax={460}
                scrollToBottom
                style={{ width:'100%'}}
              >
                  {generateMessageBlock(props.messageData)}
                </Scrollbars>
            </div>
          </React.Fragment>
        )
}

export default ChatLog;

// <div className="bubble you">
//     Hello, can you hear me?
// </div>
// <div className="bubble you">
//     I'm in California dreaming
// </div>
// <div className="bubble me">
//     ... about who we used to be.
// </div>
// <div className="bubble me">
//     Are you serious?
// </div>
// <div className="bubble you">
//     When we were younger and free...
// </div>
// <div className="bubble you">
//     I've forgotten how it felt before
// </div>

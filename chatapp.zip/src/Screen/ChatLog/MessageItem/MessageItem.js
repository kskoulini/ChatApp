import React from 'react';
import './MessageItem.css';

const MessageItem = props => {

  return(
          <React.Fragment>
            <div className={props.type}>
                {props.text}
            </div>
          </React.Fragment>
        )
}

export default MessageItem;

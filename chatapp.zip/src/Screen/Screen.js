import React,{useState} from 'react';
import './Screen.css';

import ChatItem from './ChatItem/ChatItem';
import ChatLog from './ChatLog/ChatLog';

const Screen = () => {

  // State Management
  const [currentChat, setCurrentChat] = useState({
    id:'',
    name:''
  });

  const [DUMMY_DATA, setDUMMY_DATA] = useState([
  {
      id:"person_1",
      img:"https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/thomas.jpg",
      name:"Thomas Bangalter",
      messages:[
        {
          day:"Today, 6:48 AM",
          messageList:[
            {
              type:"bubble you",
              text:"Hello"
            },
            {
              type:"bubble you",
              text:"it's me."
            },
            {
              type:"bubble you",
              text:"I was wondering..."
            }
          ]
        }
      ]
  },
  {
      id:"person_2",
      img:"https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/dog.png",
      name:"Dog Woofson",
      messages:[
        {
          day:"Today, 5:38 PM",
          messageList:
          [
            {
              type:"bubble you",
              text:"Hello, can you hear me?"
            },
            {
              type:"bubble you",
              text:"I'm in California dreaming"
            },
            {
              type:"bubble me",
              text:"... about who we used to be."
            },
            {
              type:"bubble me",
              text:"Are you serious?"
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"When we were younger and free..."
            },
            {
              type:"bubble you",
              text:"I've forgotten how it felt before"
            }
          ]
        }
      ]
  },
  {
      id:"person_3",
      img:"https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/louis-ck.jpeg",
      name:"Louis CK",
      messages:[
        {
          day:"Today, 3:38 AM",
          messageList:[
            {
              type:"bubble you",
              text:"Hey human!"
            },
            {
              type:"bubble you",
              text:"Umm... Someone stole our carpet..."
            },
            {
              type:"bubble me",
              text:"... what."
            },
            {
              type:"bubble me",
              text:"Are you serious?"
            },
            {
              type:"bubble you",
              text:"I mean..."
            },
            {
              type:"bubble you",
              text:"It’s not that bad..."
            },
            {
              type:"bubble you",
              text:"But we’re probably gonna need a new carpet."
            }
          ]
        }
      ]
  },
  {
      id:"person_4",
      img:"https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/bo-jackson.jpg",
      name:"Bo Jackson",
      messages:[
        {
          day:"Yesterday, 4:20 PM",
          messageList:[
            {
              type:"bubble me",
              text:"Heya!"
            },
            {
              type:"bubble me",
              text:"So...I lost my keys again..."
            },
            {
              type:"bubble you",
              text:"... what."
            },
            {
              type:"bubble you",
              text:"Are you serious?"
            },
            {
              type:"bubble me",
              text:"I mean..."
            },
            {
              type:"bubble me",
              text:"yeah..."
            }
          ]
        }
      ]
  },
  {
      id:"person_5",
      img:"https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/michael-jordan.jpg",
      name:"Michael Jordan",
      messages:[
        {
          day:"Today, 6:28 AM",
          messageList:[
            {
              type:"bubble you",
              text:"Wasup"
            },
            {
              type:"bubble you",
              text:"Wasup"
            },
            {
              type:"bubble you",
              text:"Wasup for the third time like are <br />you okay?"
            }
          ]
        }
      ]
  },
  {
      id:"person_6",
      img:"https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/drake.jpg",
      name:"Drake",
      messages:[
        {
          day:"Monday, 1:27 PM",
          messageList:[
            {
              type:"bubble you",
              text:"So, how's your new phone?"
            },
            {
              type:"bubble you",
              text:"You finally have a smartphone :D"
            },
            {
              type:"bubble me",
              text:"Drake?"
            },
            {
              type:"bubble me",
              text:"Why aren't you answering?"
            },
            {
              type:"bubble you",
              text:"howdoyoudoaspace???"
            }
          ]
        }
      ]
  }
])

  const [currentData,setCurrentData] = useState({})

  const [pageView,setPageView] = useState({
    state:'',
    mediaType:'media'
  })

  // State change functions
  const changeViewHandler = (key,state) => {
    const cpy = {...pageView};
    cpy[key] = state;
    setPageView(cpy);
  }

  const changeMediaTypeHandler = event => {
    let parent = event.target.parentElement;
    let current = parent.querySelector('.active-media');
    if(current){
      current.classList.remove('active-media');
    }
    event.target.classList.add('active-media');

    let mt = event.target.getAttribute('media-type');
    let cpy = {...pageView};
    cpy.mediaType = mt;
    setPageView(cpy);
    // console.log(event.target.getAttribute('media-type'));
  }
  // Populate Handlers
  const generateChatItemList = data => {
      let ItemList = [];
      let previewMessage;
      let msgTime;
      data.forEach((item, i) => {
        previewMessage = (item.messages[item.messages.length - 1].messageList[item.messages[item.messages.length - 1].messageList.length - 1].text);
        msgTime = item.messages[item.messages.length - 1].day.split(', ')[1];
        if(previewMessage.length >= 15){
          previewMessage = previewMessage.split('',15).join('') + '...';
        }
        if(item.id == currentChat.id){
          ItemList.push(<ChatItem key={item.id} activechat imgSrc={item.img} name={item.name} id={item.id} time={msgTime} preview={previewMessage} changeCurrentChatHandler={changeCurrentChatHandler}/>)
        }
        else{
          ItemList.push(<ChatItem key={item.id} imgSrc={item.img} name={item.name} id={item.id} time={msgTime} preview={previewMessage} changeCurrentChatHandler={changeCurrentChatHandler}/>)
        }
      });
      return ItemList;
  }

  const generateChatLogsList = data => {
    let id;
    const ChatLogsList = [];
    let index;

    data.forEach((person, i) => {
      id = person.id.split('_').join('');
      index = Number(person.id.split('_')[1]) - 1
      if(person.id == currentChat.id){
        ChatLogsList.push(<ChatLog activechat index={index} id={id} key={id} messageData={person.messages}/>)
      }
      else{
        ChatLogsList.push(<ChatLog index={index} id={id} key={id} messageData={person.messages}/>)
      }
    });
    return ChatLogsList;
  }

  const changeCurrentChatHandler = id => {
    let person = DUMMY_DATA.filter(x => x.id == id)[0]
    let name = person.name
    setCurrentChat({
      id:id,
      name:name
    })
  }

  // Message Handlers
  const enterTextHandler = (event) => {
    let text = event.target.value;
    let id = currentChat.id;
    let currentData_copy = {...currentData};
    currentData_copy[id] = text;
    setCurrentData({...currentData_copy});
  }

  const sendMessageHandler = (event,type) => {
    event.preventDefault();
    let text = currentData[currentChat.id];
    if(text){
      // text = text.replace(/^[ \t]+/,'');
      // text = text.replace(/[ \t]+$/,'');
      text = text.trim() // removes leading and trailing white spaces
      if(text.length != 0){
        let copy = [...DUMMY_DATA]
        let len = copy.filter(x => x.id == currentChat.id)[0].messages.length;
        copy.filter(x => x.id == currentChat.id)[0].messages[len-1].messageList.push({type:"bubble me",text:text})

        let currentData_copy = {...currentData};
        currentData_copy[currentChat.id] = '';

        setDUMMY_DATA(copy);
        setCurrentData(currentData_copy);
      }
    }
  }

  // Return content
  return(
    <div className="wrapper">
        <div className={"container"+" "+pageView.state}>
            <div className="left">
                <div className="top">
                    <input type="text" placeholder="Search"/>
                    <a href="" className="search"></a>
                </div>
                <ul className="people" style={{listStyleType:"none"}}>
                  {generateChatItemList(DUMMY_DATA)}
                </ul>
            </div>
            <div className="right">
                {
                  currentChat.id != ''?
                  <React.Fragment>
                  <div className="top">
                    <span style={{justifySelf:"left"}}>To:&nbsp;
                      <span className="name activeName">
                      {currentChat.name}
                      </span>
                    </span>
                    {
                      pageView.state === ''?
                      <div className="arrow-symbol" onClick={() => changeViewHandler('state','container-info')}>
                        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" version="1.1" width="20" height="20" x="0" y="0" viewBox="0 0 451.846 451.847" style={{enableBackground:"new 0 0 512 512"}} xmlSpace="preserve" className="">
                          <g>
                            <g xmlns="http://www.w3.org/2000/svg">
                              <path d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744   L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284   c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z" fill="#a8a8a9" data-original="#000000" className=""/>
                            </g>
                          </g>
                        </svg>
                      </div>:''
                    }
                    {
                      (pageView.state === 'container-info'||pageView.state === 'container-media')?
                      <div className="arrow-symbol arrow-turn" onClick={() => changeViewHandler('state','')}>
                        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" version="1.1" width="20" height="20" x="0" y="0" viewBox="0 0 451.846 451.847" style={{enableBackground:"new 0 0 512 512"}}>
                          <g>
                            <g xmlns="http://www.w3.org/2000/svg">
                              <path fill="#acacad" d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744   L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284   c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z" data-original="#000000" className=""/>
                            </g>
                          </g>
                        </svg>
                      </div>:''
                    }
                  </div>
                  {generateChatLogsList(DUMMY_DATA)}
                  <div className="write">
                    <a href="" className="write-link attach"></a>
                    <input type="text" value={currentData[currentChat.id]?currentData[currentChat.id]:''} onChange={enterTextHandler}/>
                    <a href="" className="write-link smiley"></a>
                    <a href="" className="write-link send" onClick={(event) => sendMessageHandler(event,0)}></a>
                  </div>
                  </React.Fragment>
                  :
                  <div className="chat-empty">
										<svg style={{margin:'auto'}} id="ec936c20-b43f-4483-857e-3751b9040ca4" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="396.618" height="329.25842" viewBox="0 0 791.2372 658.51684">
                      <title>online_chat</title>
                      <path d="M577.55634,746.82554a4.77664,4.77664,0,0,0-2.81646.99092c-2.40045-6.34374-6.11652-10.42042-10.29133-10.42042s-7.89087,4.07668-10.29132,10.42042a4.77666,4.77666,0,0,0-2.81646-.99092c-4.74294,0-8.58785,8.02129-8.58785,17.916h43.39127C586.14419,754.84683,582.29928,746.82554,577.55634,746.82554Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M470.55634,746.82554a4.77664,4.77664,0,0,0-2.81646.99092c-2.40045-6.34374-6.11652-10.42042-10.29133-10.42042s-7.89087,4.07668-10.29132,10.42042a4.77666,4.77666,0,0,0-2.81646-.99092c-4.74294,0-8.58785,8.02129-8.58785,17.916h43.39127C479.14419,754.84683,475.29928,746.82554,470.55634,746.82554Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M886.55634,746.82554a4.77664,4.77664,0,0,0-2.81646.99092c-2.40045-6.34374-6.11652-10.42042-10.29133-10.42042s-7.89087,4.07668-10.29132,10.42042a4.77666,4.77666,0,0,0-2.81646-.99092c-4.74294,0-8.58785,8.02129-8.58785,17.916h43.39127C895.14419,754.84683,891.29928,746.82554,886.55634,746.82554Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <rect x="197" y="642.25842" width="581" height="2" fill="#3f3d56"/>
                      <path d="M576.14419,764.74158H514.75308v-1c0-14.31152,5.60254-25.52246,12.75439-25.52246a7.1056,7.1056,0,0,1,3.36426.87207c3.585-8.77539,8.85694-13.77832,14.57666-13.77832s10.99219,5.00293,14.57715,13.77832a7.10566,7.10566,0,0,1,3.36426-.87207c7.15185,0,12.75439,11.21094,12.75439,25.52246Zm-59.38086-2h57.37061c-.249-12.30859-5.06787-22.52246-10.74414-22.52246a5.5581,5.5581,0,0,0-3.26856,1.166l-1.05908.76758-.4624-1.22364c-3.2749-8.65332-8.06836-13.61621-13.15137-13.61621s-9.876,4.96289-13.15088,13.61621l-.4624,1.22364-1.05908-.76758a5.5581,5.5581,0,0,0-3.26856-1.166C521.8312,740.21912,517.01236,750.433,516.76333,762.74158Z" transform="translate(-204.3814 -120.74158)" fill="#3f3d56"/>
                      <path d="M934.14419,764.74158h-61.3916v-1c0-14.31152,5.60254-25.52246,12.75488-25.52246a7.10705,7.10705,0,0,1,3.36426.87207c3.585-8.77539,8.85742-13.77832,14.57715-13.77832,5.71875,0,10.99121,5.00293,14.57617,13.77832a7.10711,7.10711,0,0,1,3.36426-.87207c7.15234,0,12.75488,11.21094,12.75488,25.52246Zm-59.38183-2h57.37207c-.249-12.30859-5.06836-22.52246-10.74512-22.52246a5.55536,5.55536,0,0,0-3.26758,1.166l-1.05957.76758-.46289-1.22364c-3.27441-8.65332-8.06836-13.61621-13.15039-13.61621-5.083,0-9.877,4.96289-13.15137,13.61621l-.46289,1.22364-1.05957-.76758a5.55536,5.55536,0,0,0-3.26758-1.166C879.83072,740.21912,875.01138,750.433,874.76236,762.74158Z" transform="translate(-204.3814 -120.74158)" fill="#3f3d56"/>
                      <path d="M477.14419,764.74158H415.75308v-1c0-14.31152,5.60254-25.52246,12.75439-25.52246a7.1056,7.1056,0,0,1,3.36426.87207c3.585-8.77539,8.85694-13.77832,14.57666-13.77832s10.99219,5.00293,14.57715,13.77832a7.10566,7.10566,0,0,1,3.36426-.87207c7.15185,0,12.75439,11.21094,12.75439,25.52246Zm-59.38086-2h57.37061c-.249-12.30859-5.06787-22.52246-10.74414-22.52246a5.5581,5.5581,0,0,0-3.26856,1.166l-1.05908.76758-.4624-1.22364c-3.2749-8.65332-8.06836-13.61621-13.15137-13.61621s-9.876,4.96289-13.15088,13.61621l-.4624,1.22364-1.05908-.76758a5.5581,5.5581,0,0,0-3.26856-1.166C422.8312,740.21912,418.01236,750.433,417.76333,762.74158Z" transform="translate(-204.3814 -120.74158)" fill="#3f3d56"/>
                      <ellipse cx="701.77479" cy="403.55785" rx="0.63807" ry="1.70152" transform="translate(-219.00337 659.80762) rotate(-57.656)" fill="#3f3d56"/>
                      <path d="M721.1178,385.90109h0a2.97765,2.97765,0,0,1,2.97765,2.97765v44.6648a2.97765,2.97765,0,0,1-2.97765,2.97765h0a0,0,0,0,1,0,0v-50.6201A0,0,0,0,1,721.1178,385.90109Z" transform="matrix(0.535, -0.84485, 0.84485, 0.535, -215.78263, 680.96592)" fill="#00b0ff"/>
                      <path d="M719.22805,385.53811h2.219a2.03479,2.03479,0,0,1,2.03479,2.03479v50.85456a2.40992,2.40992,0,0,1-2.40992,2.40992h-1.84387a0,0,0,0,1,0,0V385.53811A0,0,0,0,1,719.22805,385.53811Z" transform="translate(-218.03444 680.82783) rotate(-57.656)" fill="#3f3d56"/>
                      <rect x="704.03862" y="400.79005" width="0.85076" height="3.40303" transform="translate(-216.85204 661.58378) rotate(-57.656)" fill="#d0cde1"/>
                      <rect x="707.99182" y="403.29341" width="0.85076" height="3.40303" transform="translate(-217.12877 666.08771) rotate(-57.656)" fill="#d0cde1"/>
                      <circle cx="559.77313" cy="168.84585" r="26.8209" fill="#ffb8b8"/>
                      <path d="M765.79,308.55832s13.08336,20.6063,9.81252,26.49382S762.192,356.96678,762.192,356.96678s45.13762-33.36259,39.2501-40.55844c0,0-13.41045-11.44795-14.06462-18.6438Z" transform="translate(-204.3814 -120.74158)" fill="#ffb8b8"/>
                      <polygon points="582.342 581.607 583.65 602.214 604.584 598.616 603.275 578.664 582.342 581.607" fill="#ffb8b8"/>
                      <polygon points="489.123 593.074 485.198 606.157 508.421 610.409 511.692 598.307 489.123 593.074" fill="#ffb8b8"/>
                      <path d="M788.84938,424.83674l2.126,14.55525s26.8209,53.31472-2.28959,79.48145l-39.2501,96.81691s-4.2521,50.371-16.68129,68.03351L721.3065,723.95521l-34.01675-8.83127,27.47507-87.33147s-.32709-36.63343,3.59792-44.81053l17.33546-77.846,3.1073-83.24292S784.59729,418.62214,788.84938,424.83674Z" transform="translate(-204.3814 -120.74158)" fill="#2f2e41"/>
                      <path d="M783.77958,515.58385l14.71878,99.43359s7.85,38.26885,8.50419,52.98763,3.27084,33.68967,3.27084,33.68967l-26.49381,4.2521-26.16674-128.217Z" transform="translate(-204.3814 -120.74158)" fill="#2f2e41"/>
                      <path d="M812.89007,708.89059l-20.93339,1.30834s-7.79336-8.83127-7.33106-4.25209-4.444,23.87714-4.444,23.87714l-16.35421,17.00838s-32.38133,0-27.47507,15.7,43.17511,2.61667,43.17511,2.61667l14.71879-4.90626v6.54168s25.18548,3.59793,25.83965-2.94376,0-14.71878-.98125-15.373S812.89007,708.89059,812.89007,708.89059Z" transform="translate(-204.3814 -120.74158)" fill="#2f2e41"/>
                      <path d="M716.14419,725.03591s-14.96312-1.197-17.058-2.99263-5.38672-9.27713-9.87566-4.48893-20.64911,20.34984-20.64911,20.34984l-15.56165,7.48156s-20.34984-5.38672-27.23288,7.1823,33.81666,25.73657,44.29084,21.5469l13.16755-2.69336-.59852,6.28451s18.55427,4.18967,21.24763-1.197,4.7882-11.67124,3.59115-13.46681S716.14419,725.03591,716.14419,725.03591Z" transform="translate(-204.3814 -120.74158)" fill="#2f2e41"/>
                      <path d="M826.6276,349.77092l-23.17067,51.2639-10.06111,22.2548-3.72873,8.25235-53.96889-.65417,5.56043-37.61468c-7.85-20.27922,10.79378-28.45632,10.79378-28.45632l15.7-16.73037v2.66575s15.373-18.31672,22.24173-28.78341,16.3542-6.54168,16.3542-6.54168C822.70259,313.79167,826.6276,349.77092,826.6276,349.77092Z" transform="translate(-204.3814 -120.74158)" fill="#575a89"/>
                      <path d="M803.45693,401.03482l-10.06111,22.2548c-3.23155-6.04451-5.69123-12.89038-5.69123-16.93313,0-11.12087,11.12086-5.23335,11.12086-5.23335s-8.99482-49.22617-8.99482-63.945C789.83063,327.40163,797.98154,370.78936,803.45693,401.03482Z" transform="translate(-204.3814 -120.74158)" opacity="0.2"/>
                      <path d="M794.57335,404.72106l-48.73554-.98125s-35.65217,2.94376-30.41883,17.33546,33.68967,0,33.68967,0l56.91265,8.83128Z" transform="translate(-204.3814 -120.74158)" fill="#ffb8b8"/>
                      <path d="M803.73171,318.04376s-17.00838,1.30834-17.00838,16.02712,15.373,67.05226,15.373,67.05226-11.12086-5.88752-11.12086,5.23335,18.6438,43.50219,20.6063,21.91463c0,0,28.12924,13.73754,26.49382-12.10211s-19.298-80.46271-19.298-80.46271S816.81508,317.06251,803.73171,318.04376Z" transform="translate(-204.3814 -120.74158)" fill="#575a89"/>
                      <path d="M765.0467,286.67009c-1.87824-1.81766-1.84356-4.8833-3.35726-7.01412-2.377-3.34605-7.326-3.12175-11.38955-2.54409a31.39133,31.39133,0,0,0-7.94828,1.84681,7.83178,7.83178,0,0,0-4.5979,5.26529c-.31828,1.31813-1.02006-2.42183-1.73417-7.26566a23.59277,23.59277,0,0,1,12.91308-24.61973q.07992-.03924.15848-.07742c4.59624-2.23357,9.41131-4.20613,14.49137-4.76043s10.50081.4493,14.4851,3.64926c1.821,1.46252,3.30222,3.34007,5.25451,4.62207,3.43017,2.25247,7.77388,2.36155,11.84993,2.83641a32.9335,32.9335,0,0,1,13.20977,4.05246,17.85034,17.85034,0,0,1,8.383,10.66178c1.29061,5.25753-.81571,11.47254-5.98476,13.754a6.22935,6.22935,0,0,0-2.33634,1.71434c-4.24461,5.18888,2.60771,8.028,3.60145,12.54457.8292,3.76877-2.795,7.181-6.51177,8.21871a15.531,15.531,0,0,1-17.82585-8.5167c-1.27483-2.95648-1.56512-6.22694-1.912-9.42783-.397-3.664-10.00713-10.30037-3.51937-5.30845a9.05931,9.05931,0,0,1,2.87779,3.63976c1.97354,4.72457-2.12254,7.40633-4.31947,10.77951a11.99933,11.99933,0,0,0-.06782,12.688,13.834,13.834,0,0,1-6.35881-16.46434c.58915-1.60309,1.48213-3.08506,2.01748-4.7069.83537-2.53073.09709-7.44874-3.63814-6.45167C770.12115,286.49735,767.84272,289.37592,765.0467,286.67009Z" transform="translate(-204.3814 -120.74158)" fill="#2f2e41"/>
                      <circle cx="779.2372" cy="498.39835" r="12" fill="#d0cde1"/>
                      <circle cx="749.2372" cy="537.39835" r="20" fill="#00b0ff"/>
                      <rect x="753.63857" y="549.39835" width="2" height="93" fill="#3f3d56"/>
                      <path d="M959.6186,672.13993a21,21,0,1,1,21-21A21.0239,21.0239,0,0,1,959.6186,672.13993Zm0-40a19,19,0,1,0,19,19A19.02162,19.02162,0,0,0,959.6186,632.13993Z" transform="translate(-204.3814 -120.74158)" fill="#3f3d56"/>
                      <path d="M976.6186,636.13993a13,13,0,1,1,13-13A13.01474,13.01474,0,0,1,976.6186,636.13993Zm0-24a11,11,0,1,0,11,11A11.01245,11.01245,0,0,0,976.6186,612.13993Z" transform="translate(-204.3814 -120.74158)" fill="#3f3d56"/>
                      <path d="M644.33267,419.95252l-35.97119-35.21094H445.14419v-101h214v101H643.986ZM447.14419,382.74158H609.1774l33.10839,32.40821-.31933-32.40821h15.17773v-97h-210Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M256.95474,256.952l.34717-35.21045H242.14419v-101h214v101H292.92691Zm-12.81055-37.21045h15.17725l-.31885,32.40772,33.1084-32.40772h162.0332v-97h-210Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <rect x="76.7628" y="32" width="128" height="2" fill="#00b0ff"/>
                      <path d="M494.26285,357.85438l-17.78614-17.78614a13.077,13.077,0,0,1,17.78614-19.15088,13.0772,13.0772,0,0,1,17.78662,19.15088Zm-8.53956-38.105a11.072,11.072,0,0,0-7.83252,18.90479l16.37208,16.37207,16.37255-16.37207a11.0772,11.0772,0,0,0-15.66552-15.66553l-.707.707-.707-.707A11.04416,11.04416,0,0,0,485.72329,319.74939Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M556.26308,328.75512a2.92207,2.92207,0,1,0-4.13243,4.13243l4.13243,4.13242,4.13243-4.13242a2.92207,2.92207,0,1,0-4.13243-4.13243Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M539.26308,328.75512a2.92207,2.92207,0,1,0-4.13243,4.13243l4.13243,4.13242,4.13243-4.13242a2.92207,2.92207,0,1,0-4.13243-4.13243Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M548.14419,359.74158a22,22,0,1,1,22-22A22.02489,22.02489,0,0,1,548.14419,359.74158Zm0-42a20,20,0,1,0,20,20A20.02292,20.02292,0,0,0,548.14419,317.74158Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M602.14419,359.74158a22,22,0,1,1,22-22A22.02489,22.02489,0,0,1,602.14419,359.74158Zm0-42a20,20,0,1,0,20,20A20.02292,20.02292,0,0,0,602.14419,317.74158Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <circle cx="406.7628" cy="210" r="5" fill="#00b0ff"/>
                      <circle cx="389.7628" cy="210" r="5" fill="#00b0ff"/>
                      <path d="M595.91114,341.74158c-2.04024,14.11466,14.15066,16.97765,12.53-.00059C608.53745,341.7295,596.56351,341.75029,595.91114,341.74158Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <path d="M540.43942,344.67105c4.57267,6.14738,12.47858,6.69944,16.70477,0Z" transform="translate(-204.3814 -120.74158)" fill="#00b0ff"/>
                      <rect x="77" y="47.25842" width="128" height="2" fill="#00b0ff"/>
                      <rect x="77" y="61.25842" width="128" height="2" fill="#00b0ff"/>
                      <rect y="135.25842" width="107" height="2" fill="#3f3d56"/>
                      <rect x="382" y="298.25842" width="107" height="2" fill="#3f3d56"/>
									  </svg>
									  <p className="chat-empty-text"><span style={{fontSize:"25px"}}>Welcome to Chat!</span><br/><br/>Click on an existing chat or create a new one to start connecting :)</p>
								  </div>
                }
            </div>
            {
              pageView.state === 'container-info'?
              <div className="info-window">
                <div className="info-heading">
                  <span>Contact Info</span>
                </div>
                <img className="profile-picture" src="" alt="" />
                <span className="contact-name">Thomas Bangalter</span>
                <span className="contact-number">+93 5612791568</span>
                <div className="shared-files">
                  <div className="title">
                    <span className="title-main">Shared Media & Links</span>
                    <span className="title-extend" onClick={() => changeViewHandler('state','container-media')}>View all</span>
                  </div>
                  <div className="content">
                    <ul className="content-list">
                      <li className="content-item">
                        <div className="content-icon" style={{paddingTop: "2px"}}>
                          <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                          <g>
                            <g>
                              <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                            </g>
                          </g>
                          <g>
                            <g>
                              <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                            </g>
                          </g>
                        </svg>
                        </div>
                        <div className="content-name">
                          <span>Image.png</span>
                          <br/>
                          <span className="content-time">Oct 21, 2020 at 10:30 PM</span>
                        </div>
                      </li>
                      <li className="content-item">
                        <div className="content-icon" style={{paddingTop: "1px"}}>
                          <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="20px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                            <g>
                              <g>
                                <path fill="#595959" d="M437.333,128H330.667c-5.888,0-10.667-4.8-10.667-10.667V10.667C320,4.779,315.221,0,309.333,0H96 C78.357,0,64,14.357,64,32v448c0,17.643,14.357,32,32,32h320c17.643,0,32-14.357,32-32V138.667 C448,132.779,443.221,128,437.333,128z M426.667,480c0,5.867-4.779,10.667-10.667,10.667H96c-5.888,0-10.667-4.8-10.667-10.667V32 c0-5.867,4.779-10.667,10.667-10.667h202.667v96c0,17.643,14.357,32,32,32h96V480z"/>
                              </g>
                            </g>
                            <g>
                              <g>
                                <path fill="#595959" d="M444.864,131.136l-128-128c-4.16-4.16-10.923-4.16-15.083,0c-4.16,4.16-4.16,10.923,0,15.083l128,128 c2.091,2.069,4.821,3.115,7.552,3.115c2.731,0,5.461-1.045,7.531-3.115C449.024,142.059,449.024,135.296,444.864,131.136z"/>
                              </g>
                            </g>
                          </svg>
                        </div>
                        <div className="content-name">
                          <span>MyFile.pdf</span>
                          <br/>
                          <span className="content-time">Oct 21, 2020 at 10:30 PM</span>
                        </div>
                      </li>
                      <li className="content-item">
                        <div className="content-icon">
                          <svg height="18px" width="18px" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 511.997 511.997" style={{enableBackground:"new 0 0 511.997 511.997;"}}>
                            <g transform="translate(1 1)">
                              <g>
                                <path fill="#595959" d="M211.26,389.24l-60.331,60.331c-25.012,25.012-65.517,25.012-90.508,0.005c-24.996-24.996-24.996-65.505-0.005-90.496 l120.683-120.683c24.991-24.992,65.5-24.992,90.491,0c8.331,8.331,21.839,8.331,30.17,0c8.331-8.331,8.331-21.839,0-30.17 c-41.654-41.654-109.177-41.654-150.831,0L30.247,328.909c-41.654,41.654-41.654,109.177,0,150.831 c41.649,41.676,109.177,41.676,150.853,0l60.331-60.331c8.331-8.331,8.331-21.839,0-30.17S219.591,380.909,211.26,389.24z"/>
                                <path fill="#595959" d="M479.751,30.24c-41.654-41.654-109.199-41.654-150.853,0l-72.384,72.384c-8.331,8.331-8.331,21.839,0,30.17 c8.331,8.331,21.839,8.331,30.17,0l72.384-72.384c24.991-24.992,65.521-24.992,90.513,0c24.991,24.991,24.991,65.5,0,90.491 L316.845,283.638c-24.992,24.992-65.5,24.992-90.491,0c-8.331-8.331-21.839-8.331-30.17,0s-8.331,21.839,0,30.17 c41.654,41.654,109.177,41.654,150.831,0l132.736-132.736C521.405,139.418,521.405,71.894,479.751,30.24z"/>
                              </g>
                            </g>
                          </svg>
                        </div>
                        <div className="content-name">
                          <span>Login | Facebook</span>
                          <br/>
                          <span className="content-time">Oct 21, 2020 at 10:30 PM</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>:''
            }
            {
              pageView.state === 'container-media'?
              <div className="media-window">
                <div className="return-arrow-container">
                  <div className="return-arrow" onClick={() => changeViewHandler('state','container-info')}>
                    <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" version="1.1" width="20px" height="20px" x="0" y="0" viewBox="0 0 31.49 31.49" style={{enableBackground:"new 0 0 512 512"}}>
                      <g transform="matrix(-1,0,0,1,31.492187500000007,0)">
                        <path d="M21.205,5.007c-0.429-0.444-1.143-0.444-1.587,0c-0.429,0.429-0.429,1.143,0,1.571l8.047,8.047H1.111  C0.492,14.626,0,15.118,0,15.737c0,0.619,0.492,1.127,1.111,1.127h26.554l-8.047,8.032c-0.429,0.444-0.429,1.159,0,1.587  c0.444,0.444,1.159,0.444,1.587,0l9.952-9.952c0.444-0.429,0.444-1.143,0-1.571L21.205,5.007z" fill="#acacad" data-original="#1e201d"/>
                      </g>
                    </svg>
                  </div>
                </div>
              <div className="media-type-header">
              <span className="media-type-option active-media" media-type="media" onClick={changeMediaTypeHandler}>
              Media
              <br/>
              <span></span>
              </span>
              <span className="media-type-option" media-type="links" onClick={changeMediaTypeHandler}>
              Links
              <br/>
              <span></span>
              </span>
              <span className="media-type-option" media-type="docs" onClick={changeMediaTypeHandler}>
              Docs
              <br/>
              <span></span>
              </span>
              </div>
              {
                pageView.mediaType === 'media'?
                <div className="media-content">
                <ul className="media-list">
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Image.png</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Image.png</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Image.png</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Image.png</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                </ul>
                </div>:''
              }
              {
                pageView.mediaType === 'docs'?
                <div className="media-content">
                <ul className="media-list">
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>myDoc.docx</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>myDoc.docx</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>myDoc.docx</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>myDoc.docx</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                </ul>
                </div>:''
              }
              {
                pageView.mediaType === 'links'?
                <div className="media-content">
                <ul className="media-list">
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Login | Link</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Login | Link</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Login | Link</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                <li className="media-item">
                <div className="media-icon" style={{paddingTop: "2px"}}>
                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" height="18px" width="18px" xmlnsXlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style={{enableBackground:"new 0 0 512 512;"}}>
                <g>
                <g>
                <path fill="#595959" d="M446.575,0H65.425C29.349,0,0,29.35,0,65.426v381.149C0,482.65,29.349,512,65.425,512h381.15 C482.651,512,512,482.65,512,446.574V65.426C512,29.35,482.651,0,446.575,0z M481.842,446.575 c0,19.447-15.821,35.267-35.267,35.267H65.425c-19.447,0-35.268-15.821-35.268-35.267v-55.007l99.255-84.451 c3.622-3.082,8.906-3.111,12.562-0.075l62.174,51.628c5.995,4.977,14.795,4.569,20.304-0.946L372.181,209.77 c2.67-2.675,5.783-2.935,7.408 2.852c1.62,0.083,4.695,0.661,7.078,3.596l95.176,117.19V446.575z M481.842,279.865l-71.766-88.366 c-7.117-8.764-17.666-14.122-28.942-14.701c-11.268-0.57-22.317,3.672-30.294,11.662L212.832,326.681l-51.59-42.839 c-14.959-12.422-36.563-12.293-51.373,0.308l-79.712,67.822V65.426c0-19.447,15.821-35.268,35.268-35.268h381.15 c19.447,0,35.267,15.821,35.267,35.268V279.865z"/>
                </g>
                </g>
                <g>
                <g>
                <path fill="#595959" d="M161.174,62.995c-40.095,0-72.713,32.62-72.713,72.713c0,40.094,32.619,72.713,72.713,72.713s72.713-32.619,72.713-72.713 S201.269,62.995,161.174,62.995z M161.174,178.264c-23.466,0-42.556-19.091-42.556-42.556c0-23.466,19.09-42.556,42.556-42.556 c23.466,0,42.556,19.091,42.556,42.556S184.64,178.264,161.174,178.264z"/>
                </g>
                </g>
                </svg>
                </div>
                <div className="media-name">
                <span>Login | Link</span>
                <br/>
                <span className="media-time">Oct 21, 2020 at 10:30 PM</span>
                </div>
                </li>
                </ul>
                </div>:''
              }
              </div>:''
            }
        </div>
    </div>
  )
}

export default Screen;

// {/*<div className="chat" dataChat="person1">
//     <div className="conversation-start">
//         <span>Today, 6:48 AM</span>
//     </div>
//     <div className="bubble you">
//         Hello,
//     </div>
//     <div className="bubble you">
//         it's me.
//     </div>
//     <div className="bubble you">
//         I was wondering...
//     </div>
// </div>
// <div className="chat active-chat" dataChat="person2">
//     <div className="conversation-start">
//       <span>Today, 5:38 PM</span>
//     </div>
//     <div className="bubble you">
//         Hello, can you hear me?
//     </div>
//     <div className="bubble you">
//         I'm in California dreaming
//     </div>
//     <div className="bubble me">
//         ... about who we used to be.
//     </div>
//     <div className="bubble me">
//         Are you serious?
//     </div>
//     <div className="bubble you">
//         When we were younger and free...
//     </div>
//     <div className="bubble you">
//         I've forgotten how it felt before
//     </div>
// </div>
// <div className="chat" dataChat="person3">
//     <div className="conversation-start">
//         <span>Today, 3:38 AM</span>
//     </div>
//     <div className="bubble you">
//         Hey human!
//     </div>
//     <div className="bubble you">
//         Umm... Someone took a shit in the hallway.
//     </div>
//     <div className="bubble me">
//         ... what.
//     </div>
//     <div className="bubble me">
//         Are you serious?
//     </div>
//     <div className="bubble you">
//         I mean...
//     </div>
//     <div className="bubble you">
//         It’s not that bad...
//     </div>
//     <div className="bubble you">
//         But we’re probably gonna need a new carpet.
//     </div>
// </div>
// <div className="chat" dataChat="person4">
//     <div className="conversation-start">
//         <span>Yesterday, 4:20 PM</span>
//     </div>
//     <div className="bubble me">
//         Hey human!
//     </div>
//     <div className="bubble me">
//         Umm... Someone took a shit in the hallway.
//     </div>
//     <div className="bubble you">
//         ... what.
//     </div>
//     <div className="bubble you">
//         Are you serious?
//     </div>
//     <div className="bubble me">
//         I mean...
//     </div>
//     <div className="bubble me">
//         It’s not that bad...
//     </div>
// </div>
// <div className="chat" dataChat="person5">
//     <div className="conversation-start">
//         <span>Today, 6:28 AM</span>
//     </div>
//     <div className="bubble you">
//         Wasup
//     </div>
//     <div className="bubble you">
//         Wasup
//     </div>
//     <div className="bubble you">
//         Wasup for the third time like is <br />you blind bitch
//     </div>
// </div>
// <div className="chat" dataChat="person6">
//     <div className="conversation-start">
//         <span>Monday, 1:27 PM</span>
//     </div>
//     <div className="bubble you">
//         So, how's your new phone?
//     </div>
//     <div className="bubble you">
//         You finally have a smartphone :D
//     </div>
//     <div className="bubble me">
//         Drake?
//     </div>
//     <div className="bubble me">
//         Why aren't you answering?
//     </div>
//     <div className="bubble you">
//         howdoyoudoaspace???
//     </div>
// </div>*/}

// {/*<li className="person" dataChat="person1">
//     <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/thomas.jpg" alt="" />
//     <span className="name">Thomas Bangalter</span>
//     <span className="time">2:09 PM</span>
//     <span className="preview">I was wondering...</span>
// </li>
// <li className="person" dataChat="person2">
//     <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/dog.png" alt="" />
//     <span className="name">Dog Woofson</span>
//     <span className="time">1:44 PM</span>
//     <span className="preview">I've forgotten how it felt before</span>
// </li>
// <li className="person" dataChat="person3">
//     <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/louis-ck.jpeg" alt="" />
//     <span className="name">Louis CK</span>
//     <span className="time">2:09 PM</span>
//     <span className="preview">But we’re probably gonna need a new carpet.</span>
// </li>
// <li className="person" dataChat="person4">
//     <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/bo-jackson.jpg" alt="" />
//     <span className="name">Bo Jackson</span>
//     <span className="time">2:09 PM</span>
//     <span className="preview">It’s not that bad...</span>
// </li>
// <li className="person" dataChat="person5">
//     <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/michael-jordan.jpg" alt="" />
//     <span className="name">Michael Jordan</span>
//     <span className="time">2:09 PM</span>
//     <span className="preview">Wassup for the third time like is
// you blind pig</span>
// </li>
// <li className="person" dataChat="person6">
//     <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/382994/drake.jpg" alt="" />
//     <span className="name">Drake</span>
//     <span className="time">2:09 PM</span>
//     <span className="preview">howdoyoudoaspace</span>
// </li>*/}
